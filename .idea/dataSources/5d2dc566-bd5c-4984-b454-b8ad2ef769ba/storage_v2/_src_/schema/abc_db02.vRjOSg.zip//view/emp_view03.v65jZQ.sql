create definer = root@localhost view emp_view03 as
select `abc_db02`.`emp`.`empno`      AS `empno`,
       `abc_db02`.`emp`.`ename`      AS `ename`,
       `abc_db02`.`emp`.`deptno`     AS `deptno`,
       `abc_db02`.`salgrade`.`grade` AS `grade`
from `abc_db02`.`emp`
         join `abc_db02`.`dept`
         join `abc_db02`.`salgrade`
where ((`abc_db02`.`emp`.`deptno` = `abc_db02`.`dept`.`deptno`) and
       (`abc_db02`.`emp`.`sal` between `abc_db02`.`salgrade`.`losal` and `abc_db02`.`salgrade`.`hisal`));

