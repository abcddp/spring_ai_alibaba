create definer = root@localhost view emp_view01 as
select `abc_db02`.`emp`.`empno`  AS `empno`,
       `abc_db02`.`emp`.`ename`  AS `ename`,
       `abc_db02`.`emp`.`job`    AS `job`,
       `abc_db02`.`emp`.`deptno` AS `deptno`
from `abc_db02`.`emp`;

